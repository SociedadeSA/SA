<?php

header("Location: public/cadastro/cadastro.html"); 

?>